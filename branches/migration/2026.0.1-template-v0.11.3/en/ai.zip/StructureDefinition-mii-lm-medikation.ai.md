# MII LM Medikation - MII IG Medikation v2027.0.0-ballot.rc1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII LM Medikation**

## Logical Model: MII LM Medikation 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/LogicalModel/BasismodulMedikation | *Version*:2027.0.0-ballot.rc1 |
| Active as of 2024-11-14 | *Computable Name*:MII_LM_Medikation |

 
MII LogicalModel Module Medikation 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/de.medizininformatikinitiative.kerndatensatz.medikation|current/StructureDefinition/StructureDefinition-mii-lm-medikation.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots, and their representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-mii-lm-medikation.csv), [Excel](../StructureDefinition-mii-lm-medikation.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "mii-lm-medikation",
  "extension" : [{
    "url" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/StructureDefinition/mii-ex-meta-license-codeable",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://hl7.org/fhir/spdx-license",
        "code" : "CC-BY-4.0",
        "display" : "Creative Commons Attribution 4.0 International"
      }]
    }
  }],
  "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/LogicalModel/BasismodulMedikation",
  "version" : "2027.0.0-ballot.rc1",
  "name" : "MII_LM_Medikation",
  "_name" : {
    "extension" : [{
      "extension" : [{
        "url" : "lang",
        "valueCode" : "en-US"
      },
      {
        "url" : "content",
        "valueString" : "MII_LM_Medikation"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/translation"
    }]
  },
  "title" : "MII LM Medikation",
  "_title" : {
    "extension" : [{
      "extension" : [{
        "url" : "lang",
        "valueCode" : "en-US"
      },
      {
        "url" : "content",
        "valueString" : "MII LM Medikation"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/translation"
    }]
  },
  "status" : "active",
  "date" : "2024-11-14",
  "publisher" : "NUM-DIZ",
  "_publisher" : {
    "extension" : [{
      "extension" : [{
        "url" : "lang",
        "valueCode" : "de"
      },
      {
        "url" : "content",
        "valueString" : "NUM-DIZ"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/translation"
    }]
  },
  "contact" : [{
    "name" : "NUM-DIZ",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.netzwerk-universitaetsmedizin.de"
    }]
  }],
  "description" : "MII LogicalModel Modul Medikation",
  "_description" : {
    "extension" : [{
      "extension" : [{
        "url" : "lang",
        "valueCode" : "en-US"
      },
      {
        "url" : "content",
        "valueString" : "MII LogicalModel Module Medikation"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/translation"
    }]
  },
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "FHIR",
    "name" : "Medikation LogicalModel FHIR Mapping"
  },
  {
    "identity" : "KDS-Profile",
    "name" : "Medikation LogicalModel KDS-Profile Mapping"
  }],
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/LogicalModel/BasismodulMedikation",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Element",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "BasismodulMedikation",
      "path" : "BasismodulMedikation",
      "short" : "Das Basismodul Medikation enthält Datenelemente zur Dokumentation von Arzneimittelverordnungen und -gaben",
      "definition" : "MII LogicalModel Modul Medikation"
    },
    {
      "id" : "BasismodulMedikation.Medikation",
      "path" : "BasismodulMedikation.Medikation",
      "short" : "Medikation",
      "definition" : "Definition eines Medikamentes zum Zwecke der Verschreibung, Abgabe und Verabreichung. Es kann sich um ein fertiges Arzneimittelprodukt, einen Wirkstoff oder eine Rezeptur handeln.",
      "comment" : "FHIR-Mapping: Medication",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Medication"
      },
      {
        "identity" : "KDS-Profile",
        "map" : "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/Medication"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikation.Code",
      "path" : "BasismodulMedikation.Medikation.Code",
      "short" : "Code",
      "definition" : "Ein Code (oder eine Reihe von Codes), die dieses Medikament spezifizieren, oder eine Textbeschreibung, wenn kein Code verfügbar ist.",
      "comment" : "FHIR-Mapping: Medication.code",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Medication.code"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikation.Darreichungsform",
      "path" : "BasismodulMedikation.Medikation.Darreichungsform",
      "short" : "Darreichungsform",
      "definition" : "Darreichungsform nach EDQM",
      "comment" : "FHIR-Mapping: Medication.form",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Medication.form"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikation.Bestandteil",
      "path" : "BasismodulMedikation.Medikation.Bestandteil",
      "short" : "Bestandteil",
      "definition" : "Aktiver oder nicht-aktiver Inhaltsstoff. Identifiziert einen bestimmten Bestandteil der Medikation.",
      "comment" : "FHIR-Mapping: Medication.ingredient",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Medication.ingredient"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikation.Bestandteil.Code",
      "path" : "BasismodulMedikation.Medikation.Bestandteil.Code",
      "short" : "Code",
      "definition" : "Ein Code für den Inhaltsstoff oder Wirkstoff, z.B. aus ASK, UNII, CAS oder SNOMED CT.",
      "comment" : "FHIR-Mapping: Medication.ingredient.itemCodeableConcept",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Medication.ingredient.itemCodeableConcept"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikation.Bestandteil.Wirkstofftyp",
      "path" : "BasismodulMedikation.Medikation.Bestandteil.Wirkstofftyp",
      "short" : "Wirkstofftyp",
      "definition" : "Differenzierung des Wirkstofftyps in allgemeinen, genauen oder Kombinationswirkstoff.",
      "comment" : "FHIR-Mapping: Medication.ingredient.extension:Wirkstofftyp",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Medication.ingredient.extension:Wirkstofftyp"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikation.Bestandteil.MengeStaerke",
      "path" : "BasismodulMedikation.Medikation.Bestandteil.MengeStaerke",
      "short" : "Menge/Staerke",
      "definition" : "Wirkstärke, Menge der aktiven Substanz pro Dosiseinheit entsprechend Darreichungsform (1 Tablette, 1 Ampulle, 1 mL etc.)",
      "comment" : "FHIR-Mapping: Medication.ingredient.strength",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Ratio"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Medication.ingredient.strength"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsliste",
      "path" : "BasismodulMedikation.Medikationsliste",
      "short" : "Medikationsliste",
      "definition" : "Die Medikationsliste ist eine flache Sammlung von Medikationseinträgen, die ein Patient zu einem bestimmten Zeitpunkt einnimmt, beispielsweise bei Aufnahme oder Entlassung.",
      "comment" : "FHIR-Mapping: List",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "List"
      },
      {
        "identity" : "KDS-Profile",
        "map" : "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/medikationsliste"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsliste.Identifikation",
      "path" : "BasismodulMedikation.Medikationsliste.Identifikation",
      "short" : "Identifikator der Medikationsliste",
      "definition" : "Business Identifier der Medikationsliste",
      "comment" : "FHIR-Mapping: List.identifier",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Identifier"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "List.identifier"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsliste.Status",
      "path" : "BasismodulMedikation.Medikationsliste.Status",
      "short" : "Status",
      "definition" : "Zeigt den Status der Medikationsliste an",
      "comment" : "FHIR-Mapping: List.status",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "List.status"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsliste.Modus",
      "path" : "BasismodulMedikation.Medikationsliste.Modus",
      "short" : "Modus",
      "definition" : "Zeigt den Modus der Mediaktionsliste an - ob es sich um eine Arbeitsliste handelt, die laufend aktualisiert wird, oder um eine Momentaufnahme, beispielsweise die Liste der Medikationseinträge bei Aufnahme oder Entlassung.",
      "comment" : "FHIR-Mapping: List.mode",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "List.mode"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsliste.Typ",
      "path" : "BasismodulMedikation.Medikationsliste.Typ",
      "short" : "Typ",
      "definition" : "Definiert den Typ der Liste - warum diese erstellt wurde.",
      "comment" : "FHIR-Mapping: List.code",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "List.code"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsliste.Medikationseintrag",
      "path" : "BasismodulMedikation.Medikationsliste.Medikationseintrag",
      "short" : "Medikationseintrag",
      "definition" : "Referenz auf Medikationseintrag",
      "comment" : "FHIR-Mapping: List.entry.item",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/MedicationStatement"]
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "List.entry.item"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsliste.BezugZumPatient",
      "path" : "BasismodulMedikation.Medikationsliste.BezugZumPatient",
      "short" : "Bezug zum Patient",
      "definition" : "Die Person, für die die Medikationsliste erstellt oder verwaltet wird.",
      "comment" : "FHIR-Mapping: List.subject",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "List.subject"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsliste.BezugZumFall",
      "path" : "BasismodulMedikation.Medikationsliste.BezugZumFall",
      "short" : "Bezug zum Fall",
      "definition" : "Der Besuch, die Aufnahme oder ein anderer Kontakt zwischen Patient und Leistungserbringer, bei dem die Medikationsliste erstellt oder bearbeitet wird.",
      "comment" : "FHIR-Mapping: List.encounter",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Encounter"]
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "List.encounter"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung",
      "path" : "BasismodulMedikation.Medikationsverordnung",
      "short" : "Medikationsverordnung",
      "definition" : "Dokumentation einer Medikationsanordnung durch medizinisches Personal.",
      "comment" : "FHIR-Mapping: MedicationRequest",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest"
      },
      {
        "identity" : "KDS-Profile",
        "map" : "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationRequest"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Identifikation",
      "path" : "BasismodulMedikation.Medikationsverordnung.Identifikation",
      "short" : "Identifikator der Medikationsverordnung",
      "definition" : "Business Identifier der Medikationsverordnung",
      "comment" : "FHIR-Mapping: MedicationRequest.identifier",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Identifier"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.identifier"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Status",
      "path" : "BasismodulMedikation.Medikationsverordnung.Status",
      "short" : "Status",
      "definition" : "Status der Medikationsverordnung",
      "comment" : "FHIR-Mapping: MedicationRequest.status",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.status"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Medikation[x]",
      "path" : "BasismodulMedikation.Medikationsverordnung.Medikation[x]",
      "short" : "Medikation",
      "definition" : "Medikament, welches angeordnet wird. Es kann sich um ein fertiges Arzneimittelprodukt, einen Wirkstoff oder eine Rezeptur handeln.",
      "comment" : "FHIR-Mapping: MedicationRequest.medication[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      },
      {
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Medication"]
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.medication[x]"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen",
      "path" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen",
      "short" : "Dosierungsinstruktionen",
      "definition" : "Anweisungen, wie das Medikament eingenommen werden soll.",
      "comment" : "FHIR-Mapping: MedicationRequest.dosageInstruction",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.dosageInstruction"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Reihenfolge",
      "path" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Reihenfolge",
      "short" : "Sequenznummer des Dosierungseintrags. Bei mehreren Einträgen zur Dosierung wird damit die Reihenfolge (Priorität) der Einträge festgelegt.",
      "definition" : "Sequenznummer des Dosierungseintrags. Bei mehreren Einträgen zur Dosierung wird damit die Reihenfolge (Priorität) der Einträge festgelegt.",
      "comment" : "FHIR-Mapping: MedicationRequest.dosageInstruction.sequence",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.dosageInstruction.sequence"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Freitext",
      "path" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Freitext",
      "short" : "Dosierung (Freitext)",
      "definition" : "Textueller Eintrag der Dosierung",
      "comment" : "FHIR-Mapping: MedicationRequest.dosageInstruction.text",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.dosageInstruction.text"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Zeitangabe",
      "path" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Zeitangabe",
      "short" : "Zeitangabe zur Einnahme als Teil des Dosierschemas",
      "definition" : "Ausführliche Beispiele finden sich unter http://wiki.hl7.de/index.php?title=cdamedp:Dosierbeispiele\r\n\r\nNicht vorhanden bei Vergabe, weil bei Vergabe kein zukünftiges Dosierungs-Schema angegeben werden muss.",
      "comment" : "FHIR-Mapping: MedicationRequest.dosageInstruction.timing",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.dosageInstruction.timing"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Zeitangabe.Einnahmedauer",
      "path" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Zeitangabe.Einnahmedauer",
      "short" : "Einnahmedauer für eine angeordnete, geplante oder durchgeführte Medikamentengabe. Bei Einzel-Vergabe kann die Dauer auch punktweise (Null) sein.",
      "definition" : "Einnahmedauer für eine angeordnete, geplante oder durchgeführte Medikamentengabe. Bei Einzel-Vergabe kann die Dauer auch punktweise (Null) sein.",
      "comment" : "FHIR-Mapping: MedicationRequest.dosageInstruction.timing.bounds[x]",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.dosageInstruction.timing.bounds[x]"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Zeitangabe.Einnahmedauer.StartzeitpunktEinnahme",
      "path" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Zeitangabe.Einnahmedauer.StartzeitpunktEinnahme",
      "short" : "Startzeitpunkt der Einnahme",
      "definition" : "Startzeitpunkt der Einnahme",
      "comment" : "FHIR-Mapping: MedicationRequest.dosageInstruction.timing.boundsPeriod.start",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.dosageInstruction.timing.boundsPeriod.start"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Zeitangabe.Einnahmedauer.EndzeitpunktEinnahme",
      "path" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Zeitangabe.Einnahmedauer.EndzeitpunktEinnahme",
      "short" : "Endzeitpunkt der Einnahme",
      "definition" : "Endzeitpunkt der Einnahme",
      "comment" : "FHIR-Mapping: MedicationRequest.dosageInstruction.timing.boundsPeriod.end",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.dosageInstruction.timing.boundsPeriod.end"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Zeitangabe.Einnahmedauer.DauerDerEinnahme",
      "path" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Zeitangabe.Einnahmedauer.DauerDerEinnahme",
      "short" : "Dauer der Einnahme",
      "definition" : "Dauer der Einnahme",
      "comment" : "FHIR-Mapping: MedicationRequest.dosageInstruction.timing.boundsDuration",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Period"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.dosageInstruction.timing.boundsDuration"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Zeitangabe.Zeitpunkt",
      "path" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Zeitangabe.Zeitpunkt",
      "short" : "Zeitpunkt",
      "definition" : "Exakter Zeitpunkt, zu dem eine Medikation gegeben werden soll.",
      "comment" : "FHIR-Mapping: MedicationRequest.dosageInstruction.timing.event",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.dosageInstruction.timing.event"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Zeitangabe.EreignisbezogeneWiederholung",
      "path" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Zeitangabe.EreignisbezogeneWiederholung",
      "short" : "Ereignisbezogene Wiederholung",
      "definition" : "Gibt ein periodisches Zeitintervall an, in dem die Wiederholung auf Aktivitäten des täglichen Lebens oder anderen wichtigen Ereignissen basiert, die zeitabhängig sind, jedoch nicht vollständig von der Zeit bestimmt werden",
      "comment" : "FHIR-Mapping: MedicationRequest.dosageInstruction.timing.repeat.when in Kombination mit MedicationRequest.dosageInstruction.timing.repeat.offset und/oder anderen Angaben in MedicationRequest.dosageInstruction.timing.repeat",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.dosageInstruction.timing.repeat.when"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Zeitangabe.EreignisbezogeneWiederholung.Ereignis",
      "path" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Zeitangabe.EreignisbezogeneWiederholung.Ereignis",
      "short" : "Ereignis",
      "definition" : "Ereignis, z. B. morgens, mittags, abends, zur Nacht",
      "comment" : "FHIR-Mapping: MedicationRequest.dosageInstruction.timing.repeat.when .dayOfWeek .timeOfDay etc.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.dosageInstruction.timing.repeat.when"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Zeitangabe.EreignisbezogeneWiederholung.Offset",
      "path" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Zeitangabe.EreignisbezogeneWiederholung.Offset",
      "short" : "Offset",
      "definition" : "Offset zum Ereignis, z. B. 30 Minuten vorher",
      "comment" : "FHIR-Mapping: MedicationRequest.dosageInstruction.timing.repeat.offset",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "unsignedInt"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.dosageInstruction.timing.repeat.offset"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Zeitangabe.PeriodischesIntervall",
      "path" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Zeitangabe.PeriodischesIntervall",
      "short" : "Periodisches Intervall",
      "definition" : "Ein Zeitintervall, das sich periodisch wiederholt. Periodische Intervalle haben zwei Eigenschaften, Phase und Periode. Die Phase gibt den \"Typ\" Intervall\" an, der sich jede Periode wiederholt.\r\n\r\nWiederholungsintervall (periodische Intervallsequenz), gibt an\r\ndie Dauer jedes Vorkommens bzw. der Zeit zwischen den Vorkommnissen (period) \r\nder Ankerzeitpunkt (Startzeitpunkt), an dem die periodische Intervallsequenz beginnt (phase).",
      "comment" : "FHIR-Mapping: MedicationRequest.dosageInstruction.timing.repeat",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.dosageInstruction.timing.repeat"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Zeitangabe.PeriodischesIntervall.Phase",
      "path" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Zeitangabe.PeriodischesIntervall.Phase",
      "short" : "Ankerzeitpunkt (Startzeitpunkt), an dem die periodische Intervallsequenz beginnt",
      "definition" : "Ankerzeitpunkt (Startzeitpunkt), an dem die periodische Intervallsequenz beginnt",
      "comment" : "FHIR-Mapping: MedicationRequest.dosageInstruction.timing.event",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "dateTime"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.dosageInstruction.timing.event"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Zeitangabe.PeriodischesIntervall.Periode[x]",
      "path" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Zeitangabe.PeriodischesIntervall.Periode[x]",
      "short" : "Dauer jedes Vorkommens bzw. der Zeit zwischen den Vorkommnissen",
      "definition" : "Dauer jedes Vorkommens bzw. der Zeit zwischen den Vorkommnissen",
      "comment" : "FHIR-Mapping: MedicationRequest.dosageInstruction.timing.repeat.(boundsDuration|boundsPeriod)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Period"
      },
      {
        "code" : "Duration"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.dosageInstruction.timing.repeat.(boundsDuration|boundsPeriod)"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.EinnahmeBeiBedarf[x]",
      "path" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.EinnahmeBeiBedarf[x]",
      "short" : "Einnahme bei Bedarf",
      "definition" : "Einnahme des Medikaments bei Bedarf",
      "comment" : "FHIR-Mapping: MedicationRequest.dosageInstruction.asNeeded[x] entweder als Boolean .asNeededBoolean  oder kodiert .asNeededCodeableConcept",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      },
      {
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.dosageInstruction.asNeeded[x]"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.ArtDerAnwendung",
      "path" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.ArtDerAnwendung",
      "short" : "Art der Anwendung",
      "definition" : "Art der Anwendung des Arzneimittels EDQM passende Value Sets. Pharmazeutische Anwendung dekomponiert in drei Eigenschaften: Art der Anwendung, Weg der Anwendung und Ort der Anwendung.",
      "comment" : "FHIR-Mappings: MedicationRequest.dosageInstruction.(site|route|method) jeweils mit einem .coding oder .text für kodierte Angabe mit EDQM binding und im Freitext",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.dosageInstruction.(site|route|method)"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Dosis[x]",
      "path" : "BasismodulMedikation.Medikationsverordnung.Dosierungsinstruktionen.Dosis[x]",
      "short" : "Dosis",
      "definition" : "Kann angegeben sein als Mengenangabe (SimpleQuantity, Range) oder als Menge pro Zeiteinheit (Ratio).\r\nMöglicherweise wichtig sind Maximaldosierungen innerhalb einer Zeiteinheit oder max. Lebenszeitdosis.",
      "comment" : "FHIR-Mapping: MedicationRequest.dosageInstruction.doseAndRate mit den Teilangaben je nach Anforderung .type .dose .rate .type gibt die Art des Eintrages an .dose kann als SimpleQuantity (.doseQuantity) oder als Range (.doseRange) angegeben werden .rate kann als Ratio (.rateRatio), Range (.rateRange) oder  SimpleQuantity (.rateQuantity) angegeben werden",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Range"
      },
      {
        "code" : "Quantity",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/SimpleQuantity"]
      },
      {
        "code" : "Ratio"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.dosageInstruction.doseAndRate"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Hinweis",
      "path" : "BasismodulMedikation.Medikationsverordnung.Hinweis",
      "short" : "Hinweistext zu diesem Medikament",
      "definition" : "Hinweistext zu diesem Medikament",
      "comment" : "FHIR-Mapping: MedicationRequest.note",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Annotation"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.note"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Behandlungsgrund[x]",
      "path" : "BasismodulMedikation.Medikationsverordnung.Behandlungsgrund[x]",
      "short" : "Behandlungsgrund",
      "definition" : "Behandlungsgrund kann ein Problem, Symptom oder eine Diagnose (Condition) sein.",
      "comment" : "FHIR-Mapping: MedicationRequest.(reasonCode|reasonReference)",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "CodeableConcept"
      },
      {
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Condition",
        "http://hl7.org/fhir/StructureDefinition/Observation"]
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.(reasonCode|reasonReference)"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.DatumDerVerordnung",
      "path" : "BasismodulMedikation.Medikationsverordnung.DatumDerVerordnung",
      "short" : "Datum des Dokumentationseintrages",
      "definition" : "Datum des Dokumentationseintrages",
      "comment" : "FHIR Mapping: MedicationRequest.authoredOn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.authoredOn"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Ersatzmedikation[x]",
      "path" : "BasismodulMedikation.Medikationsverordnung.Ersatzmedikation[x]",
      "short" : "Ersatzmedikation",
      "definition" : "Zeigt an, ob die Substitution Teil der Abgabe sein kann oder soll oder nicht. In einigen Fällen muss eine Substitution stattfinden, in anderen Fällen darf sie nicht stattfinden.",
      "comment" : "FHIR Mapping: MedicationRequest.substitution",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      },
      {
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.substitution"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Verordnungsdetails",
      "path" : "BasismodulMedikation.Medikationsverordnung.Verordnungsdetails",
      "short" : "Verordnungsdetails",
      "definition" : "Ob es sich bei der Anfrage um einen Vorschlag, einen Plan oder einen Auftrag handelt.",
      "comment" : "FHIR Mapping: MedicationRequest.intent",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.intent"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.BezugZumPatient",
      "path" : "BasismodulMedikation.Medikationsverordnung.BezugZumPatient",
      "short" : "Bezug zum Patient",
      "definition" : "Ein Link zu einer Ressource, die die Person repräsentiert, an die das Medikament verabreicht werden soll.",
      "comment" : "FHIR Mapping: MedicationRequest.subject",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.subject"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.BezugZumFall",
      "path" : "BasismodulMedikation.Medikationsverordnung.BezugZumFall",
      "short" : "Bezug zum Fall",
      "definition" : "Die Fall, bei der diese Verordnung erstellt wurde oder mit der die Erstellung dieser Verordnung in engem Zusammenhang steht.",
      "comment" : "FHIR Mapping: MedicationRequest.encounter",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Encounter"]
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.encounter"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.VorherigeMedikationsverordnungen",
      "path" : "BasismodulMedikation.Medikationsverordnung.VorherigeMedikationsverordnungen",
      "short" : "Vorherige Medikationsverordnungen",
      "definition" : "Ein Link zu einer Ressource, die eine frühere Verschreibung darstellt.",
      "comment" : "FHIR Mapping: MedicationRequest.priorPrescription",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/MedicationRequest"]
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.priorPrescription"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.Kontraindikationen",
      "path" : "BasismodulMedikation.Medikationsverordnung.Kontraindikationen",
      "short" : "Kontraindikationen",
      "definition" : "Weist auf ein tatsächliches oder potenzielles klinisches Problem mit oder zwischen einer oder mehreren aktiven oder vorgeschlagenen klinischen Maßnahmen für einen Patienten hin, z. B. Wechselwirkung zwischen Arzneimitteln, doppelte Therapie, Dosierungswarnung usw.",
      "comment" : "FHIR Mapping: MedicationRequest.detectedIssue",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/DetectedIssue"]
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.detectedIssue"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverordnung.AutorInformantDerVerordnung",
      "path" : "BasismodulMedikation.Medikationsverordnung.AutorInformantDerVerordnung",
      "short" : "Autor Informant der Verordnung.",
      "definition" : "Zuständiger Health Professional, der den Vorgang angelegt hat bzw. Informationen zu dem Vorgang bereit gestellt hat.",
      "comment" : "FHIR-Mapping: MedicationRequest.requester",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Organization"]
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.requester"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag",
      "path" : "BasismodulMedikation.Medikationseintrag",
      "short" : "Medikationseintrag",
      "definition" : "Medikationseintrag: Dokumentiert die Verschreibung, Gabe oder Einnahme zu einem oder mehreren Medikamenten z.B. in einem Medikationsplan.",
      "comment" : "FHIR-Mapping: MedicationStatement",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement"
      },
      {
        "identity" : "KDS-Profile",
        "map" : "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationStatement"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Identifikation",
      "path" : "BasismodulMedikation.Medikationseintrag.Identifikation",
      "short" : "Identifikation",
      "definition" : "Identifikator des Medikationseintrags",
      "comment" : "FHIR-Mapping: MedicationStatement.identifier",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Identifier"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.identifier"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Status",
      "path" : "BasismodulMedikation.Medikationseintrag.Status",
      "short" : "Prozess-Status des beschriebenen Medikationsstatus",
      "definition" : "Prozess-Status des beschriebenen Medikationsstatus",
      "comment" : "FHIR-Mapping: MedicationStatement.status",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.status"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Medikation[x]",
      "path" : "BasismodulMedikation.Medikationseintrag.Medikation[x]",
      "short" : "Medikation",
      "definition" : "Definition eines Medikamentes zum Zwecke der Verschreibung, Abgabe und Verabreichung. Es kann sich um ein fertiges Arzneimittelprodukt, einen Wirkstoff oder eine Rezeptur handeln.",
      "comment" : "FHIR-Mapping: MedicationStatement.medication[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      },
      {
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Medication"]
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.medication[x]"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer",
      "path" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer",
      "short" : "Einnahmedauer",
      "definition" : "Einnahmedauer für eine angeordnete, geplante oder durchgeführte Medikamentengabe. Bei Einzel-Vergabe kann die Dauer auch punktweise (Null) sein.",
      "comment" : "FHIR-Mapping: MedicationStatement.effective[x]",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.effective[x]"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.StartzeitpunktEinnahme",
      "path" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.StartzeitpunktEinnahme",
      "short" : "Startzeitpunkt der Einnahme",
      "definition" : "Startzeitpunkt der Einnahme",
      "comment" : "FHIR-Mapping: MedicationStatement.effectivePeriod.start",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.effectivePeriod.start"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.EndzeitpunktEinnahme",
      "path" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.EndzeitpunktEinnahme",
      "short" : "Endzeitpunkt der Einnahme",
      "definition" : "Endzeitpunkt der Einnahme",
      "comment" : "FHIR-Mapping: MedicationStatement.effectivePeriod.end",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.effectivePeriod.end"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.DauerDerEinnahme",
      "path" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.DauerDerEinnahme",
      "short" : "Dauer der Einnahme",
      "definition" : "Dauer der Einnahme",
      "comment" : "FHIR-Mapping: MedicationStatement.effectivePeriod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Period"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.effectivePeriod"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung",
      "path" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung",
      "short" : "Dosierung",
      "definition" : "Gibt an, wie das Medikament vom Patienten eingenommen wird/wurde oder werden soll.",
      "comment" : "FHIR-Mapping: MedicationStatement.dosage",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.dosage"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Reihenfolge",
      "path" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Reihenfolge",
      "short" : "Sequenznummer des Dosierungseintrags. Bei mehreren Einträgen zur Dosierung wird damit die Reihenfolge (Priorität) der Einträge festgelegt.",
      "definition" : "Sequenznummer des Dosierungseintrags. Bei mehreren Einträgen zur Dosierung wird damit die Reihenfolge (Priorität) der Einträge festgelegt.",
      "comment" : "FHIR-Mapping: MedicationStatement.dosage.sequence",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.dosage.sequence"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Freitext",
      "path" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Freitext",
      "short" : "Dosierung (Freitext)",
      "definition" : "Textueller Eintrag der Dosierung",
      "comment" : "FHIR-Mapping: MedicationStatement.dosage.text",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.dosage.text"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Zeitangabe",
      "path" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Zeitangabe",
      "short" : "Zeitangabe zur Einnahme als Teil des Dosierschemas",
      "definition" : "Ausführliche Beispiele finden sich unter http://wiki.hl7.de/index.php?title=cdamedp:Dosierbeispiele\r\n\r\nNicht vorhanden bei Vergabe, weil bei Vergabe kein zukünftiges Dosierungs-Schema angegeben werden muss.",
      "comment" : "FHIR-Mapping: MedicationStatement.dosage.timing",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.dosage.timing"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Zeitangabe.Einnahmedauer",
      "path" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Zeitangabe.Einnahmedauer",
      "short" : "Einnahmedauer für eine angeordnete, geplante oder durchgeführte Medikamentengabe. Bei Einzel-Vergabe kann die Dauer auch punktweise (Null) sein.",
      "definition" : "Einnahmedauer für eine angeordnete, geplante oder durchgeführte Medikamentengabe. Bei Einzel-Vergabe kann die Dauer auch punktweise (Null) sein.",
      "comment" : "FHIR-Mapping: MedicationStatement.dosage.timing.bounds[x]",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.dosage.timing.bounds[x]"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Zeitangabe.Einnahmedauer.StartzeitpunktEinnahme",
      "path" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Zeitangabe.Einnahmedauer.StartzeitpunktEinnahme",
      "short" : "Startzeitpunkt der Einnahme",
      "definition" : "Startzeitpunkt der Einnahme",
      "comment" : "FHIR-Mapping: MedicationStatement.dosage.timing.boundsPeriod.start",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.dosage.timing.boundsPeriod.start"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Zeitangabe.Einnahmedauer.EndzeitpunktEinnahme",
      "path" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Zeitangabe.Einnahmedauer.EndzeitpunktEinnahme",
      "short" : "Endzeitpunkt der Einnahme",
      "definition" : "Endzeitpunkt der Einnahme",
      "comment" : "FHIR-Mapping: MedicationStatement.dosage.timing.boundsPeriod.end",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.dosage.timing.boundsPeriod.end"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Zeitangabe.Einnahmedauer.DauerDerEinnahme",
      "path" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Zeitangabe.Einnahmedauer.DauerDerEinnahme",
      "short" : "Dauer der Einnahme",
      "definition" : "Dauer der Einnahme",
      "comment" : "FHIR-Mapping: MedicationStatement.dosage.timing.boundsDuration",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Period"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.dosage.timing.boundsDuration"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Zeitangabe.Zeitpunkt",
      "path" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Zeitangabe.Zeitpunkt",
      "short" : "Zeitpunkt",
      "definition" : "Exakter Zeitpunkt, zu dem eine Medikation gegeben werden soll.",
      "comment" : "FHIR-Mapping: MedicationStatement.dosage.timing.event",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.dosage.timing.event"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Zeitangabe.EreignisbezogeneWiederholung",
      "path" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Zeitangabe.EreignisbezogeneWiederholung",
      "short" : "Ereignisbezogene Wiederholung",
      "definition" : "Gibt ein periodisches Zeitintervall an, in dem die Wiederholung auf Aktivitäten des täglichen Lebens oder anderen wichtigen Ereignissen basiert, die zeitabhängig sind, jedoch nicht vollständig von der Zeit bestimmt werden",
      "comment" : "FHIR-Mapping: MedicationStatement.dosage.timing.repeat.when in Kombination mit MedicationStatement.dosage.timing.repeat.offset und/oder anderen Angaben in MedicationStatement.dosage.timing.repeat",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.dosage.timing.repeat"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Zeitangabe.EreignisbezogeneWiederholung.Ereignis",
      "path" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Zeitangabe.EreignisbezogeneWiederholung.Ereignis",
      "short" : "Ereignis",
      "definition" : "Ereignis, z. B. morgens, mittags, abends, zur Nacht",
      "comment" : "FHIR-Mapping: MedicationStatement.dosage.timing.repeat.when .dayOfWeek .timeOfDay etc.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.dosage.timing.repeat.when"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Zeitangabe.EreignisbezogeneWiederholung.Offset",
      "path" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Zeitangabe.EreignisbezogeneWiederholung.Offset",
      "short" : "Offset",
      "definition" : "Offset zum Ereignis, z. B. 30 Minuten vorher",
      "comment" : "FHIR-Mapping: MedicationStatement.dosage.timing.repeat.offset",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "unsignedInt"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.dosage.timing.repeat.offset"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Zeitangabe.PeriodischesIntervall",
      "path" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Zeitangabe.PeriodischesIntervall",
      "short" : "Periodisches Intervall",
      "definition" : "Ein Zeitintervall, das sich periodisch wiederholt. Periodische Intervalle haben zwei Eigenschaften, Phase und Periode. Die Phase gibt den \"Typ\" Intervall\" an, der sich jede Periode wiederholt.\r\n\r\nWiederholungsintervall (periodische Intervallsequenz), gibt an\r\ndie Dauer jedes Vorkommens bzw. der Zeit zwischen den Vorkommnissen (period) \r\nder Ankerzeitpunkt (Startzeitpunkt), an dem die periodische Intervallsequenz beginnt (phase).",
      "comment" : "FHIR-Mapping: MedicationStatement.dosage.timing.repeat",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.dosage.timing.repeat"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Zeitangabe.PeriodischesIntervall.Phase",
      "path" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Zeitangabe.PeriodischesIntervall.Phase",
      "short" : "Ankerzeitpunkt (Startzeitpunkt), an dem die periodische Intervallsequenz beginnt",
      "definition" : "Ankerzeitpunkt (Startzeitpunkt), an dem die periodische Intervallsequenz beginnt",
      "comment" : "FHIR-Mapping: MedicationStatement.dosage.timing.event",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "dateTime"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.dosage.timing.event"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Zeitangabe.PeriodischesIntervall.Periode[x]",
      "path" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Zeitangabe.PeriodischesIntervall.Periode[x]",
      "short" : "Dauer jedes Vorkommens bzw. der Zeit zwischen den Vorkommnissen",
      "definition" : "Dauer jedes Vorkommens bzw. der Zeit zwischen den Vorkommnissen",
      "comment" : "FHIR-Mapping: MedicationStatement.dosage.timing.repeat.(boundsDuration|boundsPeriod)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Period"
      },
      {
        "code" : "Duration"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.dosage.timing.repeat.(boundsDuration|boundsPeriod)"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.EinnahmeBeiBedarf[x]",
      "path" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.EinnahmeBeiBedarf[x]",
      "short" : "Einnahme bei Bedarf",
      "definition" : "Einnahme des Medikaments bei Bedarf",
      "comment" : "FHIR-Mapping: MedicationStatement.dosage.asNeeded[x] entweder als Boolean .asNeededBoolean  oder kodiert .asNeededCodeableConcept",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      },
      {
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.dosage.asNeeded[x]"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.ArtDerAnwendung",
      "path" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.ArtDerAnwendung",
      "short" : "Art der Anwendung",
      "definition" : "Art der Anwendung des Arzneimittels EDQM passende Value Sets. Pharmazeutische Anwendung dekomponiert in drei Eigenschaften: Art der Anwendung, Weg der Anwendung und Ort der Anwendung.",
      "comment" : "FHIR-Mappings: MedicationStatement.dosage.(site|route|method) jeweils mit einem .coding oder .text für kodierte Angabe mit EDQM binding und im Freitext",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.dosage.(site|route|method)"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Dosis[x]",
      "path" : "BasismodulMedikation.Medikationseintrag.Einnahmedauer.Dosierung.Dosis[x]",
      "short" : "Dosis",
      "definition" : "Kann angegeben sein als Mengenangabe (SimpleQuantity, Range) oder als Menge pro Zeiteinheit (Ratio).\r\nMöglicherweise wichtig sind Maximaldosierungen innerhalb einer Zeiteinheit oder max. Lebenszeitdosis.",
      "comment" : "FHIR-Mapping: MedicationStatement.dosage.doseAndRate mit den Teilangaben je nach Anforderung .type .dose .rate .type gibt die Art des Eintrages an .dose kann als SimpleQuantity (.doseQuantity) oder als Range (.doseRange) angegeben werden .rate kann als Ratio (.rateRatio), Range (.rateRange) oder  SimpleQuantity (.rateQuantity) angegeben werden",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Range"
      },
      {
        "code" : "Quantity",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/SimpleQuantity"]
      },
      {
        "code" : "Ratio"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.dosage.doseAndRate"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Hinweis",
      "path" : "BasismodulMedikation.Medikationseintrag.Hinweis",
      "short" : "Hinweistext zu diesem Medikament",
      "definition" : "Hinweistext zu diesem Medikament",
      "comment" : "FHIR-Mapping: MedicationStatement.note",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Annotation"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.note"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.Behandlungsgrund[x]",
      "path" : "BasismodulMedikation.Medikationseintrag.Behandlungsgrund[x]",
      "short" : "Behandlungsgrund",
      "definition" : "Behandlungsgrund kann ein Problem, Symptom oder eine Diagnose (Condition) sein.",
      "comment" : "FHIR-Mapping: MedicationStatement.(reasonCode|reasonReference)",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "CodeableConcept"
      },
      {
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Condition",
        "http://hl7.org/fhir/StructureDefinition/Observation"]
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.(reasonCode|reasonReference)"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.BezugZuVerordnung",
      "path" : "BasismodulMedikation.Medikationseintrag.BezugZuVerordnung",
      "short" : "Bezug zu Verordnung. Hier können je nach Anforderung unterschiedliche Bezüge zum Fall, Behandlungsplan etc. hergestellt werden.",
      "definition" : "Bezug zu Verordnung. Hier können je nach Anforderung unterschiedliche Bezüge zum Fall, Behandlungsplan etc. hergestellt werden.",
      "comment" : "FHIR-Mappings: MedicationStatement.basedOn",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/MedicationRequest"]
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.basedOn"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.BezugZuAbgabe",
      "path" : "BasismodulMedikation.Medikationseintrag.BezugZuAbgabe",
      "short" : "Bezug zu Abgabe",
      "definition" : "Bezug zu Abgabe",
      "comment" : "FHIR-Mappings: MedicationStatement.basedOn",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/MedicationAdministration"]
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.basedOn"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.BezugZumPatient",
      "path" : "BasismodulMedikation.Medikationseintrag.BezugZumPatient",
      "short" : "Bezug zum Patient",
      "definition" : "Die Person, die das Medikament einnimmt/eingesetzt hat.",
      "comment" : "FHIR Mapping: MedicationStatement.subject",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.subject"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.BezugZumFall",
      "path" : "BasismodulMedikation.Medikationseintrag.BezugZumFall",
      "short" : "Bezug zum Fall",
      "definition" : "Der Besuch, die Aufnahme oder ein anderer Kontakt zwischen Patient und Leistungserbringer, bei dem die Verabreichung des Medikaments erfolgt ist.",
      "comment" : "FHIR Mapping: MedicationStatement.context",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Encounter"]
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.context"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.DatumDesEintrags",
      "path" : "BasismodulMedikation.Medikationseintrag.DatumDesEintrags",
      "short" : "Datum des Dokumentationseintrages",
      "definition" : "Datum des Dokumentationseintrages",
      "comment" : "FHIR-Mapping: MedicationStatement.dateAsserted",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.dateAsserted"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationseintrag.AutorInformantDesEintrags",
      "path" : "BasismodulMedikation.Medikationseintrag.AutorInformantDesEintrags",
      "short" : "Zuständiger Health Professional, der den Vorgang angelegt hat bzw. Informationen zu dem Vorgang bereit gestellt hat.",
      "definition" : "Zuständiger Health Professional, der den Vorgang angelegt hat bzw. Informationen zu dem Vorgang bereit gestellt hat.",
      "comment" : "FHIR-Mapping: MedicationStatement.informationSource",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Organization"]
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.informationSource"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverabreichung",
      "path" : "BasismodulMedikation.Medikationsverabreichung",
      "short" : "Medikationsverabreichung",
      "definition" : "Beschreibt das Ereignis, bei dem ein Patient ein Medikament einnimmt oder ihm auf andere Weise verabreicht wird. Dies kann das Schlucken einer Tablette oder eine lang laufende Infusion sein.",
      "comment" : "FHIR-Mapping: MedicationAdministration",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationAdministration"
      },
      {
        "identity" : "KDS-Profile",
        "map" : "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationAdministration"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverabreichung.Identifikation",
      "path" : "BasismodulMedikation.Medikationsverabreichung.Identifikation",
      "short" : "Identifikation",
      "definition" : "Identifikator der Medikationsverabreichung",
      "comment" : "FHIR-Mapping: MedicationAdministration.identifier",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Identifier"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationAdministration.identifier"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverabreichung.Status",
      "path" : "BasismodulMedikation.Medikationsverabreichung.Status",
      "short" : "Status",
      "definition" : "Zeigt den Status der Medikationsverabreichung an.",
      "comment" : "FHIR-Mapping: MedicationAdministration.status",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationAdministration.status"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverabreichung.Medikation[x]",
      "path" : "BasismodulMedikation.Medikationsverabreichung.Medikation[x]",
      "short" : "Medikation",
      "definition" : "Definition eines Medikamentes zum Zwecke der Verschreibung, Abgabe und Verabreichung. Es kann sich um ein fertiges Arzneimittelprodukt, einen Wirkstoff oder eine Rezeptur handeln.",
      "comment" : "FHIR-Mapping: MedicationAdministration.medication[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      },
      {
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Medication"]
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationAdministration.medication[x]"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverabreichung.Verabreichungszeitpunkt[x]",
      "path" : "BasismodulMedikation.Medikationsverabreichung.Verabreichungszeitpunkt[x]",
      "short" : "Verabreichungszeitpunkt",
      "definition" : "Zeitpunkt oder Zeitintervall in dem die Verabreichung stattgefunden hat.",
      "comment" : "FHIR-Mapping: MedicationAdministration.effective[x]",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      },
      {
        "code" : "Period"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationAdministration.effective[x]"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverabreichung.Dosierung",
      "path" : "BasismodulMedikation.Medikationsverabreichung.Dosierung",
      "short" : "Dosierung",
      "definition" : "Details zur Dosierung der Medikation",
      "comment" : "FHIR-Mapping: MedicationAdministration.dosage",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationAdministration.dosage"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverabreichung.Dosierung.Freitext",
      "path" : "BasismodulMedikation.Medikationsverabreichung.Dosierung.Freitext",
      "short" : "Freitext",
      "definition" : "Freitext der Dosierungsinformationen",
      "comment" : "FHIR-Mapping: MedicationAdministration.dosage.text",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationAdministration.dosage.text"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverabreichung.Dosierung.Koerperstelle",
      "path" : "BasismodulMedikation.Medikationsverabreichung.Dosierung.Koerperstelle",
      "short" : "Koerperstelle",
      "definition" : "Eine kodierte Angabe der anatomischen Stelle, an der das Medikament zuerst in den Körper gelangt ist.",
      "comment" : "FHIR-Mapping: MedicationAdministration.dosage.site",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationAdministration.dosage.site"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverabreichung.Dosierung.Weg",
      "path" : "BasismodulMedikation.Medikationsverabreichung.Dosierung.Weg",
      "short" : "Weg",
      "definition" : "Ein Code, der den Zugangsweg oder den physiologischen Weg der Verabreichung eines therapeutischen Mittels in oder an den Patienten angibt. Zum Beispiel topisch, intravenös, usw.",
      "comment" : "FHIR-Mapping: MedicationAdministration.dosage.route",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationAdministration.dosage.route"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverabreichung.Dosierung.Dosis",
      "path" : "BasismodulMedikation.Medikationsverabreichung.Dosierung.Dosis",
      "short" : "Dosis",
      "definition" : "Die Menge des Medikaments, die bei einem Verabreichungsvorgang verabreicht wird. Wird verwendet, wenn die Verabreichung im Wesentlichen ein sofortiges Ereignis ist, wie das Schlucken einer Tablette oder die Verabreichung einer Injektion.",
      "comment" : "FHIR-Mapping: MedicationAdministration.dosage.dose",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Quantity",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/SimpleQuantity"]
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationAdministration.dosage.dose"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverabreichung.Dosierung.Rate[x]",
      "path" : "BasismodulMedikation.Medikationsverabreichung.Dosierung.Rate[x]",
      "short" : "Rate",
      "definition" : "Gibt die Geschwindigkeit an, mit der das Medikament dem Patienten zugeführt wurde oder wird. In der Regel die Rate für eine Infusion, z. B. 100 ml pro 1 Stunde oder 100 ml/Stunde. Kann auch als Rate pro Zeiteinheit ausgedrückt werden, z. B. 500 ml pro 2 Stunden. Andere Beispiele: 200 mcg/min oder 200 mcg/1 Minute; 1 Liter/8 Stunden.",
      "comment" : "FHIR-Mapping: MedicationAdministration.dosage.rate[x]",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Ratio"
      },
      {
        "code" : "Quantity"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationAdministration.dosage.rate[x]"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverabreichung.Hinweis",
      "path" : "BasismodulMedikation.Medikationsverabreichung.Hinweis",
      "short" : "Hinweis",
      "definition" : "Informationen über die Verabreichung",
      "comment" : "FHIR-Mapping: MedicationAdministration.note",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Annotation"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationAdministration.note"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverabreichung.Behandlungsgrund[x]",
      "path" : "BasismodulMedikation.Medikationsverabreichung.Behandlungsgrund[x]",
      "short" : "Behandlungsgrund",
      "definition" : "Grund für die Durchführung der Verabreichung",
      "comment" : "FHIR-Mapping: MedicationAdministration.(reasonCode|reasonReference)",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "CodeableConcept"
      },
      {
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Condition",
        "http://hl7.org/fhir/StructureDefinition/Observation",
        "http://hl7.org/fhir/StructureDefinition/DiagnosticReport"]
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationAdministration.(reasonCode|reasonReference)"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverabreichung.BezugZuVerordnung",
      "path" : "BasismodulMedikation.Medikationsverabreichung.BezugZuVerordnung",
      "short" : "Bezug zu Verordnung",
      "definition" : "Referenz auf die Medikationsverordnung, welche die Mediaktionsverabreichung anordnet.",
      "comment" : "FHIR-Mappings: MedicationAdministration.request",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/MedicationRequest"]
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationAdministration.request"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverabreichung.BezugZuPatient",
      "path" : "BasismodulMedikation.Medikationsverabreichung.BezugZuPatient",
      "short" : "Bezug zu Patient",
      "definition" : "Die Person, die das Medikament erhält.",
      "comment" : "FHIR Mapping: MedicationAdministration.subject",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationAdministration.subject"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverabreichung.BezugZuFall",
      "path" : "BasismodulMedikation.Medikationsverabreichung.BezugZuFall",
      "short" : "Bezug zu Fall",
      "definition" : "Der Besuch, die Aufnahme oder ein anderer Kontakt zwischen Patient und Leistungserbringer, bei dem die Verabreichung des Medikaments erfolgt ist.",
      "comment" : "FHIR Mapping: MedicationAdministration.context",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Encounter"]
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationAdministration.context"
      }]
    },
    {
      "id" : "BasismodulMedikation.Medikationsverabreichung.Durchfuehrender",
      "path" : "BasismodulMedikation.Medikationsverabreichung.Durchfuehrender",
      "short" : "Durchführende*r",
      "definition" : "Gibt an, wer oder was die Verabreichung der Medikamente durchgeführt hat.",
      "comment" : "FHIR Mapping: MedicationAdministration.performer",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Practitioner",
        "http://hl7.org/fhir/StructureDefinition/PractitionerRole",
        "http://hl7.org/fhir/StructureDefinition/Patient",
        "http://hl7.org/fhir/StructureDefinition/RelatedPerson",
        "http://hl7.org/fhir/StructureDefinition/Device"]
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationAdministration.performer"
      }]
    }]
  }
}

```
