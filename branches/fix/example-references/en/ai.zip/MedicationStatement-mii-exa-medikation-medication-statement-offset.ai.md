# mii-exa-medikation-medication-statement-offset - MII IG Medikation v2027.0.0-ballot.rc3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **mii-exa-medikation-medication-statement-offset**

## Example MedicationStatement: mii-exa-medikation-medication-statement-offset

-------

**English**

-------

Profile: [MII PR Medikation MedicationStatement](StructureDefinition-mii-pr-medikation-medication-statement.md) version: 2027.0.0-ballot.rc3

Security Label: [test health data (Details: ActReason code HTEST = 'test health data')](http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActReason.html)

**status**: Active

**medication**: L-Thyroxin Henning 125 50 Tbl. N2

**subject**: [Max Mustermann Male, DoB: 1965-03-14 ( http://example.org/fhir/sid/patienten#12345)](Patient-mii-exa-medikation-patient.md)

**effective**: 2020-05-27 17:57:00+0100

> **dosage****timing**: 30min , before breakfast, Once per 1 day**route**: Oral use

### DoseAndRates

| | |
| :--- | :--- |
| - | **Dose[x]** |
| * | 125 Mikrogramm (Details: UCUM codeug = 'ug') |




## Resource Content

```json
{
  "resourceType" : "MedicationStatement",
  "id" : "mii-exa-medikation-medication-statement-offset",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationStatement|2027.0.0-ballot.rc3"],
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "code" : "HTEST",
      "display" : "test health data"
    }]
  },
  "status" : "active",
  "medicationCodeableConcept" : {
    "coding" : [{
      "system" : "http://fhir.de/CodeSystem/ifa/pzn",
      "code" : "02532793",
      "display" : "L-Thyroxin Henning 125 50 Tbl. N2"
    }]
  },
  "subject" : {
    "reference" : "Patient/mii-exa-medikation-patient"
  },
  "effectiveDateTime" : "2020-05-27T17:57:00+01:00",
  "dosage" : [{
    "timing" : {
      "repeat" : {
        "frequency" : 1,
        "period" : 1,
        "periodUnit" : "d",
        "when" : ["ACM"],
        "offset" : 30
      }
    },
    "route" : {
      "coding" : [{
        "system" : "http://standardterms.edqm.eu",
        "code" : "20053000",
        "display" : "Oral use"
      }]
    },
    "doseAndRate" : [{
      "doseQuantity" : {
        "value" : 125,
        "unit" : "Mikrogramm",
        "system" : "http://unitsofmeasure.org",
        "code" : "ug"
      }
    }]
  }]
}

```
