# Beispiele - MII IG Medikation v2027.0.0-ballot.rc3

* [**Inhaltsverzeichnis**](toc.md)
* **Beispiele**

## Beispiele

 Diese Seite enthält Übersetzungen aus der Originalsprache, in der der Leitfaden verfasst wurde. Informationen zu diesen Übersetzungen und Anweisungen zum Abgeben von Feedback zu den Übersetzungen finden Sie [hier](translationinfo.md). 

Diese Seite führt die Beispielinstanzen des Moduls **MII IG Medikation** auf. Die Vorlage enthält das synthetische Beispiel [Max Mustermann-Testpatient](Patient-mii-exa-medikation-patient.md).

**Nur synthetische Daten** — niemals echte oder realistisch wirkende Patientendaten in Beispielen verwenden.

> [TODO: Ergänzen Sie aussagekräftige Beispielinstanzen zu Ihren Profilen.]

