# mii-param-medikation-manifest - MII IG Medikation v2027.0.0-ballot

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **mii-param-medikation-manifest**

## Parameters: mii-param-medikation-manifest



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "mii-param-medikation-manifest",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-manifestparameters"]
  },
  "parameter" : [{
    "name" : "system-version",
    "valueCanonical" : "http://snomed.info/sct|http://snomed.info/sct/900000000000207008/version/20250701"
  },
  {
    "name" : "system-version",
    "valueCanonical" : "http://terminology.hl7.org/CodeSystem/artifact-version-policy-codes|3.0.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/shareablecodesystem|4.0.2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishablecodesystem|2.0.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/shareablevalueset|4.0.2"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishablevalueset|2.0.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-computablevalueset|2.0.0"
  },
  {
    "name" : "system-version",
    "valueCanonical" : "http://ihe-d.de/CodeSystems/FallkontextBeiDokumentenerstellung|2021-07-06T21:19:41"
  },
  {
    "name" : "system-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/CodeSystem/mii-cs-medikation-pzn-sales-status-code|2027.0.0-ballot"
  },
  {
    "name" : "system-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/CodeSystem/wirkstofftyp|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareablecapabilitystatement|2.0.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishablecapabilitystatement|2.0.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/List|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Resource-id|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Resource-lastUpdated|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Resource-profile|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/clinical-code|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/clinical-date|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/List-empty-reason|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/clinical-encounter|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/clinical-identifier|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/List-item|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/clinical-patient|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/List-source|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/List-status|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/List-subject|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/SearchParameter/mii-sp-meta-medication-list-mode|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/Medication|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Medication-expiration-date|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Medication-form|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Medication-identifier|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Medication-ingredient|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Medication-ingredient-code|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Medication-lot-number|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Medication-manufacturer|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/Medication-status|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/SearchParameter/mii-sp-meta-medication-ingredient-strength|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/SearchParameter/mii-sp-meta-medication-ingredient-strength-numerator|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/SearchParameter/mii-sp-meta-medication-ingredient-strength-denominator|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/MedicationAdministration|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/MedicationAdministration-context|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/MedicationAdministration-effective-time|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/medications-medication|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/MedicationAdministration-performer|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/MedicationAdministration-reason-given|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/MedicationAdministration-reason-not-given|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/MedicationAdministration-request|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/medications-status|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/MedicationAdministration-subject|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/SearchParameter/mii-sp-meta-medication-dosage-site|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/SearchParameter/mii-sp-meta-medication-dosage-route|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/SearchParameter/mii-sp-meta-medication-dosage-dosequantity|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/SearchParameter/mii-sp-meta-medication-dosage-ratequantity|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/SearchParameter/mii-sp-meta-medication-dosage-rateratio-numerator|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/SearchParameter/mii-sp-meta-medication-dosage-rateratio-denominator|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/SearchParameter/mii-sp-meta-medication-dosage-rateratio|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/SearchParameter/mii-sp-meta-medication-partof|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/MedicationRequest|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/MedicationRequest-authoredon|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/MedicationRequest-category|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/medications-date|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/medications-encounter|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/MedicationRequest-intended-dispenser|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/MedicationRequest-intended-performer|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/MedicationRequest-intended-performertype|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/MedicationRequest-intent|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/MedicationRequest-priority|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/MedicationRequest-requester|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/MedicationRequest-subject|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/SearchParameter/mii-sp-meta-medication-dosage-doserange-low|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/SearchParameter/mii-sp-meta-medication-dosage-doserange-high|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/SearchParameter/mii-sp-meta-medication-dosage-doserange|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/SearchParameter/mii-sp-meta-medication-dosage-raterange-low|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/SearchParameter/mii-sp-meta-medication-dosage-raterange-high|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/SearchParameter/mii-sp-meta-medication-dosage-raterange|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/MedicationStatement|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/MedicationStatement-category|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/MedicationStatement-context|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/MedicationStatement-effective|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/MedicationStatement-part-of|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/MedicationStatement-source|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/SearchParameter/MedicationStatement-subject|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareableimplementationguide|2.0.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishableimplementationguide|2.0.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-implementationguide|2.0.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/medikationsliste|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationAdministration|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/Medication|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationRequest|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/MedicationStatement|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareablestructuredefinition|2.0.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishablestructuredefinition|2.0.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/Extension|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/Element|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/Substance|4.0.1"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/ValueSet/wirkstofftyp|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/Patient|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/Encounter|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/SimpleQuantity|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/Condition|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/Observation|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/DetectedIssue|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/Organization|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/DiagnosticReport|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/Practitioner|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/PractitionerRole|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/RelatedPerson|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/Device|4.0.1"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/DomainResource|4.0.1"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://hl7.org/fhir/ValueSet/all-languages|4.0.1"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/ValueSet/mii-vs-medikation-atc|2027.0.0-ballot"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://hl7.org/fhir/uv/ips/ValueSet/body-site-uv-ips|2.0.0"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://hl7.org/fhir/uv/ips/ValueSet/medicine-route-of-administration|2.0.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://ig.fhir.de/igs/medication/StructureDefinition/DosageDE|1.0.7"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://ig.fhir.de/igs/medication/StructureDefinition/TimingDE|1.0.7"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "http://hl7.org/fhir/StructureDefinition/Timing|4.0.1"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://ig.fhir.de/igs/medication/ValueSet/DosageDoseQuantityDE|1.0.7"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://terminology.hl7.org/ValueSet/v3-ActSubstanceAdminSubstitutionCode|3.0.0"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://terminology.hl7.org/ValueSet/v3-SubstanceAdminSubstitutionReason|3.0.0"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://hl7.org/fhir/ValueSet/medication-statement-category|4.0.1"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/ValueSet/fallkontext|2027.0.0-ballot"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "http://hl7.org/fhir/uv/ips/ValueSet/medicine-doseform|2.0.0"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/wirkstofftyp|2027.0.0-ballot"
  },
  {
    "name" : "default-canonical-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/StructureDefinition/wirkstoffrelation|2027.0.0-ballot"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/ValueSet/mii-vs-medikation-ask|2027.0.0-ballot"
  },
  {
    "name" : "default-valueset-version",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/ValueSet/mii-vs-medikation-unii|2027.0.0-ballot"
  }]
}

```
